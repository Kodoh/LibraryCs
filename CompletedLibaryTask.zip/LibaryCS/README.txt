Slogin - is staff login and is the start of the project

Menu - menu and can be accessed via the staff login

libary.db - The database for all of the tables used

actions - holds files which are performing tasks to help run Slogin / menu
	SQL functions - all of the SQL functions for the whole project are used here
	classes - folder for classes
__init__ - initialisation folder for the tables in the database

Test Plan - https://docs.google.com/document/d/1wWMWB9okuF66Tw1gSXc1GdnJiZB2_vFSY8nLTehDTdo/edit

